const dataset = [
  {
    id: 1,
    branch: "Гражданское право",
    jurisdiction: "ГК РФ",
    article: "Статья 10 ГК РФ",
    rubberPhrase: "заведомо недобросовестное осуществление гражданских прав",
    normText: "Не допускаются действия в обход закона с противоправной целью, а также иное заведомо недобросовестное осуществление гражданских прав.",
    type: "Качественная",
    keywords: ["добросовестность", "злоупотребление правом", "обход закона"],
    caseTitle: "Пленум ВС РФ № 25 от 23.06.2015",
    court: "Верховный Суд РФ",
    year: 2015,
    caseNumber: "Постановление Пленума № 25",
    caseType: "Разъяснение высшего суда",
    outcome: "Суд может сам поставить вопрос о недобросовестности",
    outcomeType: "Нейтральный ориентир",
    interpretation: "Широкое, коррективное",
    facts: "Пленум разъяснил, что добросовестность участников оборота предполагается, пока не доказано иное, но суд не связан исключительно доводами сторон и вправе сам вынести на обсуждение обстоятельства недобросовестности.",
    motivation: "Критерий добросовестности привязан к стандарту поведения, учитывающему права и законные интересы другой стороны. Если поведение явно отклоняется от этого стандарта, суд может отказать в защите права полностью или частично.",
    practicalValue: "Это одна из базовых точек входа в практику по каучуковым категориям «добросовестность» и «злоупотребление правом».",
    sourceLabel: "ВС РФ, Постановление Пленума № 25",
    sourceUrl: "https://www.vsrf.ru/files/14913/"
  },
  {
    id: 2,
    branch: "Гражданское право",
    jurisdiction: "ГК РФ",
    article: "Пункт 2 статьи 450 ГК РФ",
    rubberPhrase: "существенное нарушение договора",
    normText: "По требованию одной из сторон договор может быть изменен или расторгнут по решению суда при существенном нарушении договора другой стороной.",
    type: "Качественная",
    keywords: ["существенное нарушение", "расторжение договора", "договор"],
    caseTitle: "Обзор судебной практики ВС РФ № 1 (2015)",
    court: "Верховный Суд РФ",
    year: 2015,
    caseNumber: "Обзор № 1 (2015)",
    caseType: "Обзор практики",
    outcome: "Одностороннее расторжение без прямого основания не допускается",
    outcomeType: "Отказ в произвольном расторжении",
    interpretation: "Сдержанное, ограничительное",
    facts: "В обзоре Верховный Суд подчеркнул, что расторжение договора по требованию одной стороны в судебном порядке возможно только при существенном нарушении либо в иных случаях, прямо предусмотренных законом или договором.",
    motivation: "Само недовольство исполнением ещё не тождественно существенному нарушению. Суд оценивает, лишилась ли сторона в значительной степени того, на что вправе была рассчитывать при заключении договора.",
    practicalValue: "Норма часто используется в спорах о поставке, аренде и иных длящихся договорах, где требуется оценка тяжести нарушения.",
    sourceLabel: "ВС РФ, Обзор № 1 (2015)",
    sourceUrl: "https://www.vsrf.ru/files/14845/"
  },
  {
    id: 3,
    branch: "Гражданское право",
    jurisdiction: "ГК РФ",
    article: "Статья 451 ГК РФ",
    rubberPhrase: "существенное изменение обстоятельств",
    normText: "Существенное изменение обстоятельств, из которых стороны исходили при заключении договора, является основанием для его изменения или расторжения.",
    type: "Качественная",
    keywords: ["существенное изменение обстоятельств", "COVID-19", "расторжение договора"],
    caseTitle: "Обзор ВС РФ по COVID-19 № 1 от 21.04.2020",
    court: "Верховный Суд РФ",
    year: 2020,
    caseNumber: "Обзор № 1 от 21.04.2020",
    caseType: "Обзор практики",
    outcome: "Пандемия и ограничения могут учитываться как основание по ст. 451 ГК РФ",
    outcomeType: "Допущение изменения/расторжения",
    interpretation: "Контекстуальное, гибкое",
    facts: "Верховный Суд указал, что ограничения, связанные с распространением COVID-19, могут рассматриваться как обстоятельства, которые стороны не могли разумно предвидеть при заключении договоров.",
    motivation: "Речь не идёт об автоматическом расторжении всех договоров: суд проверяет весь набор условий ст. 451 ГК РФ, в том числе распределение риска и характер нарушенного баланса интересов.",
    practicalValue: "Это один из самых наглядных примеров того, как каучуковая формула наполняется содержанием в экстраординарной ситуации.",
    sourceLabel: "ВС РФ, Обзор по COVID-19 № 1",
    sourceUrl: "https://vsrf.ru/press_center/news/28855/"
  },
  {
    id: 4,
    branch: "Гражданское право",
    jurisdiction: "ГК РФ",
    article: "Пункт 2 статьи 428 ГК РФ",
    rubberPhrase: "явно обременительные условия",
    normText: "Присоединившаяся сторона вправе требовать изменения или расторжения договора, если он содержит явно обременительные для неё условия, которые она не приняла бы при наличии возможности участвовать в определении условий договора.",
    type: "Качественная",
    keywords: ["договор присоединения", "явно обременительные условия", "слабая сторона"],
    caseTitle: "Постановление КС РФ № 14-П от 03.04.2023",
    court: "Конституционный Суд РФ",
    year: 2023,
    caseNumber: "14-П/2023",
    caseType: "Постановление КС РФ",
    outcome: "Конституционный Суд усилил защиту присоединившейся стороны",
    outcomeType: "В пользу слабой стороны",
    interpretation: "Защитное, расширительное",
    facts: "Конституционный Суд проверял конституционность пунктов 2 и 3 статьи 428 ГК РФ в связи с жалобой гражданина К.В. Матюшова и подтвердил необходимость эффективной защиты стороны, реально не влиявшей на условия договора.",
    motivation: "Оценка «явной обременительности» не может быть формальной: суд должен учитывать реальное договорное неравенство, экономический контекст и фактическую возможность обсуждать условия.",
    practicalValue: "Эта позиция полезна для пользовательских соглашений, банковских, страховых и иных стандартных договоров.",
    sourceLabel: "КС РФ, Постановление № 14-П",
    sourceUrl: "https://publication.pravo.gov.ru/document/0001202304060001"
  },
  {
    id: 5,
    branch: "Гражданское право",
    jurisdiction: "ГК РФ",
    article: "Пункт 2 статьи 314 ГК РФ",
    rubberPhrase: "разумный срок",
    normText: "При непредъявлении кредитором требования об исполнении такого обязательства должник вправе потребовать от кредитора принять исполнение, если иное не предусмотрено законом, иными правовыми актами, условиями обязательства или не явствует из обычаев либо существа обязательства.",
    type: "Количественная",
    keywords: ["разумный срок", "исполнение обязательства", "неопределённый срок"],
    caseTitle: "Определение ВС РФ от 25.08.2016 № 301-ЭС16-4469",
    court: "Верховный Суд РФ",
    year: 2016,
    caseNumber: "А11-352/2015",
    caseType: "Определение Судебной коллегии по экономическим спорам",
    outcome: "Срок, завязанный на действия подрядчика, не делает договор неопределённым",
    outcomeType: "Подтверждение действительности условия",
    interpretation: "Функциональное, стабилизирующее",
    facts: "В споре о подряде Верховный Суд исходил из того, что если срок оплаты привязан к предоставлению банковской гарантии, то соответствующее действие должно быть совершено в предусмотренный договором или, при его отсутствии, в разумный срок.",
    motivation: "Суд отверг подход, при котором любая подобная привязка автоматически делает срок несогласованным. Категория «разумного срока» используется для сохранения определённости обязательства, а не для его разрушения.",
    practicalValue: "Хороший пример того, как оценочная формула используется для поддержания оборота, а не только для санкций.",
    sourceLabel: "ВС РФ, Определение № 301-ЭС16-4469; Обзор ВС РФ № 3 (2016)",
    sourceUrl: "https://www.consultant.ru/law/podborki/razumnyj_srok_314_gk/"
  },
  {
    id: 6,
    branch: "Гражданское право",
    jurisdiction: "ГК РФ",
    article: "Статьи 151 и 1101 ГК РФ",
    rubberPhrase: "требования разумности и справедливости",
    normText: "При определении размера компенсации морального вреда должны учитываться требования разумности и справедливости.",
    type: "Качественная",
    keywords: ["моральный вред", "разумность", "справедливость", "компенсация"],
    caseTitle: "Обзор судебной практики ВС РФ № 2 (2015)",
    court: "Верховный Суд РФ",
    year: 2015,
    caseNumber: "Обзор № 2 (2015)",
    caseType: "Обзор практики",
    outcome: "Размер компенсации подлежит корректировке с учётом обстоятельств страданий и вины",
    outcomeType: "Индивидуализация размера",
    interpretation: "Оценочное, балансирующее",
    facts: "В обзоре Верховный Суд напомнил, что размер компенсации морального вреда не может определяться механически: требуется учёт характера страданий, степени вины и иных значимых обстоятельств.",
    motivation: "Категории «разумность» и «справедливость» позволяют суду не связывать себя жёсткой формулой, но требуют мотивированного объяснения, почему именно такой размер признаётся соразмерным.",
    practicalValue: "Одна из самых узнаваемых каучуковых формул гражданского права.",
    sourceLabel: "ВС РФ, Обзор № 2 (2015)",
    sourceUrl: "https://vsrf.ru/files/15006/"
  },
  {
    id: 7,
    branch: "Процессуальное право",
    jurisdiction: "ГПК РФ",
    article: "Статья 6.1 ГПК РФ",
    rubberPhrase: "разумный срок судопроизводства",
    normText: "Судопроизводство в судах и исполнение судебного постановления осуществляются в разумные сроки.",
    type: "Количественная",
    keywords: ["разумный срок судопроизводства", "компенсация", "эффективность действий суда"],
    caseTitle: "Постановление Пленума ВС РФ № 11 от 29.03.2016",
    court: "Верховный Суд РФ",
    year: 2016,
    caseNumber: "Постановление Пленума № 11",
    caseType: "Разъяснение высшего суда",
    outcome: "Нарушение процессуального срока само по себе не равно нарушению разумного срока",
    outcomeType: "Уточнение критерия",
    interpretation: "Системное, многофакторное",
    facts: "В делах о компенсации за нарушение права на судопроизводство в разумный срок Верховный Суд исходит из совокупной оценки сложности дела, поведения участников, эффективности действий суда и общей длительности процесса.",
    motivation: "Разумность не сводится к календарю. Суды оценивают не только формальные сроки, но и объективную сложность спора, а также наличие периодов необъяснимого бездействия.",
    practicalValue: "Норма важна для процессуального блока платформы и для разъяснения пользователям разницы между 'срок по кодексу' и 'разумный срок'.",
    sourceLabel: "ГПК РФ ст. 6.1; Пленум ВС РФ № 11",
    sourceUrl: "https://www.consultant.ru/document/cons_doc_LAW_195918/"
  },
  {
    id: 8,
    branch: "Уголовное право",
    jurisdiction: "УК РФ",
    article: "Статья 330 УК РФ",
    rubberPhrase: "существенный вред",
    normText: "Самоуправство образует состав преступления, если такими действиями причинён существенный вред.",
    type: "Качественная",
    keywords: ["существенный вред", "самоуправство", "уголовная квалификация"],
    caseTitle: "Определение ВС РФ № 41-Д11-36",
    court: "Верховный Суд РФ",
    year: 2011,
    caseNumber: "41-Д11-36",
    caseType: "Определение по уголовному делу",
    outcome: "Судебные акты отменены из-за ошибочной оценки существенности вреда",
    outcomeType: "Отмена осуждения",
    interpretation: "Строгое, ограничительное",
    facts: "По делу о самоуправстве нижестоящие суды признали существенный вред исходя из номинальной стоимости имущества, но Верховный Суд указал, что необходимо учитывать реальную хозяйственную ценность объекта, а не абстрактную цифру.",
    motivation: "Для уголовно-правовой оценки важен не любой ущерб, а именно общественно опасные последствия достаточной значимости. Если вред определён формально, состав преступления может отпасть.",
    practicalValue: "Это наглядный пример того, как каучуковая формула в уголовном праве толкуется осторожно и с повышенными требованиями к доказанности.",
    sourceLabel: "КонсультантПлюс, подборка по ст. 330 УК РФ",
    sourceUrl: "https://www.consultant.ru/law/podborki/suschestvennyj_vred_po_st._330_uk_rf/"
  }
];

const lessons = [
  {
    id: 1,
    linkedId: 3,
    question: "Можно ли автоматически расторгнуть договор только потому, что после его заключения наступила пандемия и ограничения?",
    options: [
      { text: "Да, пандемия сама по себе всегда означает расторжение", correct: false },
      { text: "Нет, суд проверяет полный набор условий статьи 451 ГК РФ", correct: true },
      { text: "Да, если одна из сторон просто перестала исполнять обязательство", correct: false }
    ],
    explanation: "Позиция Верховного Суда по обзору COVID-19 строится не на автоматизме, а на совокупной проверке условий статьи 451 ГК РФ: предвидимость, распределение риска, характер нарушенного баланса интересов."
  },
  {
    id: 2,
    linkedId: 4,
    question: "Что должен выяснить суд, когда сторона ссылается на 'явно обременительные условия' договора присоединения?",
    options: [
      { text: "Только подписывал ли истец договор добровольно", correct: false },
      { text: "Имелась ли у стороны реальная возможность влиять на условия и не нарушен ли баланс интересов", correct: true },
      { text: "Достаточно установить, что договор соответствует закону формально", correct: false }
    ],
    explanation: "После постановления КС РФ № 14-П акцент смещён на реальное, а не фиктивное участие стороны в определении условий и на фактическое договорное неравенство."
  },
  {
    id: 3,
    linkedId: 8,
    question: "Как в уголовном праве проверяется 'существенный вред' для состава самоуправства?",
    options: [
      { text: "По любой бухгалтерской стоимости имущества", correct: false },
      { text: "Через реальную значимость вреда и его общественно опасные последствия", correct: true },
      { text: "Достаточно самого факта спора между сторонами", correct: false }
    ],
    explanation: "В определении № 41-Д11-36 Верховный Суд отверг чисто формальный подход: существенность вреда должна подтверждаться реальными последствиями, а не номинальной оценкой объекта."
  }
];

const els = {
  stats: document.getElementById("stats"),
  results: document.getElementById("results"),
  resultsCount: document.getElementById("resultsCount"),
  searchInput: document.getElementById("searchInput"),
  resetBtn: document.getElementById("resetBtn"),
  branchFilter: document.getElementById("branchFilter"),
  jurisdictionFilter: document.getElementById("jurisdictionFilter"),
  outcomeFilter: document.getElementById("outcomeFilter"),
  interpretationFilter: document.getElementById("interpretationFilter"),
  yearFilter: document.getElementById("yearFilter"),
  lessonBox: document.getElementById("lessonBox"),
  aiNorm: document.getElementById("aiNorm"),
  aiOutcome: document.getElementById("aiOutcome"),
  aiInterpretation: document.getElementById("aiInterpretation"),
  aiExplainBtn: document.getElementById("aiExplainBtn"),
  aiOutput: document.getElementById("aiOutput"),
  modal: document.getElementById("caseModal"),
  modalContent: document.getElementById("modalContent"),
  modalClose: document.getElementById("modalClose"),
  themeToggle: document.getElementById("themeToggle")
};

const state = {
  q: "",
  branch: "",
  jurisdiction: "",
  outcome: "",
  interpretation: "",
  year: ""
};

function uniqueValues(key) {
  return [...new Set(dataset.map(item => item[key]))].sort((a, b) => String(a).localeCompare(String(b), "ru"));
}

function fillSelect(select, values) {
  values.forEach(value => {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    select.appendChild(option);
  });
}

function renderStats() {
  const branches = new Set(dataset.map(item => item.branch)).size;
  const courts = new Set(dataset.map(item => item.court)).size;
  const years = `${Math.min(...dataset.map(i => i.year))}–${Math.max(...dataset.map(i => i.year))}`;
  els.stats.innerHTML = `
    <span class="stat-pill"><strong>${dataset.length}</strong> карточек практики</span>
    <span class="stat-pill"><strong>${branches}</strong> отрасли</span>
    <span class="stat-pill"><strong>${courts}</strong> уровня практики</span>
    <span class="stat-pill"><strong>${years}</strong> диапазон лет</span>
  `;
}

function normalize(text) {
  return String(text).toLowerCase().trim();
}

function filterData() {
  return dataset.filter(item => {
    const haystack = normalize([
      item.branch,
      item.jurisdiction,
      item.article,
      item.rubberPhrase,
      item.normText,
      item.caseTitle,
      item.caseNumber,
      item.outcome,
      item.interpretation,
      item.facts,
      item.motivation,
      item.keywords.join(" ")
    ].join(" "));

    const qMatch = !state.q || haystack.includes(normalize(state.q));
    const branchMatch = !state.branch || item.branch === state.branch;
    const jurisdictionMatch = !state.jurisdiction || item.jurisdiction === state.jurisdiction;
    const outcomeMatch = !state.outcome || item.outcomeType === state.outcome;
    const interpretationMatch = !state.interpretation || item.interpretation === state.interpretation;
    const yearMatch = !state.year || String(item.year) === String(state.year);

    return qMatch && branchMatch && jurisdictionMatch && outcomeMatch && interpretationMatch && yearMatch;
  });
}

function outcomeClass(outcomeType) {
  if (/в пользу|допущение|индивидуализация|подтверждение/i.test(outcomeType)) return "outcome-win";
  if (/отказ|отмена/i.test(outcomeType)) return "outcome-loss";
  return "neutral";
}

function createCard(item) {
  const article = document.createElement("article");
  article.className = "result-card";
  article.innerHTML = `
    <div class="case-top">
      <span class="branch-badge">${item.branch}</span>
      <div class="tag-list">
        <span class="pill ${outcomeClass(item.outcomeType)}">${item.outcomeType}</span>
        <span class="pill neutral">${item.interpretation}</span>
      </div>
    </div>

    <div>
      <h4 class="result-title">${item.article}</h4>
      <p class="muted">Каучуковая формула: <strong>${item.rubberPhrase}</strong></p>
    </div>

    <div class="norm-quote">${item.normText}</div>

    <div class="meta-grid">
      <div class="meta-item">
        <div class="meta-label">Судебный акт</div>
        <div>${item.caseTitle}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">Реквизиты</div>
        <div>${item.caseNumber} · ${item.year}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">Суд</div>
        <div>${item.court}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">Тип нормы</div>
        <div>${item.type}</div>
      </div>
    </div>

    <div class="motivation-box">
      <strong>Итог:</strong> ${item.outcome}<br />
      <strong>Мотивировка:</strong> ${item.motivation}
    </div>

    <div class="tag-list">
      ${item.keywords.map(tag => `<span class="pill neutral">${tag}</span>`).join("")}
    </div>

    <div class="card-footer">
      <div class="case-links">
        <button class="text-link-btn" data-open="${item.id}">Открыть карточку кейса</button>
        <a class="text-link-btn" href="${item.sourceUrl}" target="_blank" rel="noreferrer">Источник</a>
      </div>
    </div>
  `;
  return article;
}

function renderResults() {
  const data = filterData();
  els.results.innerHTML = "";
  els.resultsCount.textContent = `Найдено: ${data.length}`;

  if (!data.length) {
    els.results.innerHTML = `<div class="card"><h4>Ничего не найдено</h4><p class="muted">Попробуйте убрать часть фильтров или изменить поисковый запрос.</p></div>`;
    return;
  }

  data.forEach(item => els.results.appendChild(createCard(item)));

  document.querySelectorAll("[data-open]").forEach(btn => {
    btn.addEventListener("click", () => openModal(Number(btn.dataset.open)));
  });
}

function openModal(id) {
  const item = dataset.find(entry => entry.id === id);
  if (!item) return;

  const relatedLesson = lessons.find(lesson => lesson.linkedId === item.id);
  els.modalContent.innerHTML = `
    <section class="modal-section">
      <span class="branch-badge">${item.branch}</span>
      <h3>${item.article}</h3>
      <p class="muted">${item.jurisdiction} · ${item.type} каучуковая норма</p>
    </section>

    <section class="modal-section">
      <h4>Формулировка</h4>
      <div class="norm-quote">${item.normText}</div>
      <p><strong>Ключевая оценочная категория:</strong> ${item.rubberPhrase}</p>
    </section>

    <section class="modal-section">
      <h4>Судебная практика</h4>
      <div class="meta-grid">
        <div class="meta-item"><div class="meta-label">Акт</div><div>${item.caseTitle}</div></div>
        <div class="meta-item"><div class="meta-label">Суд</div><div>${item.court}</div></div>
        <div class="meta-item"><div class="meta-label">Реквизиты</div><div>${item.caseNumber}</div></div>
        <div class="meta-item"><div class="meta-label">Итог</div><div>${item.outcome}</div></div>
      </div>
    </section>

    <section class="modal-section">
      <h4>Фабула / смысл позиции</h4>
      <p>${item.facts}</p>
    </section>

    <section class="modal-section">
      <h4>Мотивация суда</h4>
      <div class="motivation-box">${item.motivation}</div>
      <p><strong>Практическая ценность:</strong> ${item.practicalValue}</p>
    </section>

    <section class="modal-section">
      <h4>Ключевые слова</h4>
      <div class="tag-list">${item.keywords.map(tag => `<span class="pill neutral">${tag}</span>`).join("")}</div>
    </section>

    <section class="modal-section">
      <h4>Источник</h4>
      <div class="sources-list">
        <span class="pill neutral">${item.sourceLabel}</span>
        <a href="${item.sourceUrl}" target="_blank" rel="noreferrer">Открыть источник</a>
      </div>
    </section>

    ${relatedLesson ? `
    <section class="modal-section">
      <h4>Связанный учебный кейс</h4>
      <p>${relatedLesson.question}</p>
    </section>` : ""}
  `;
  els.modal.classList.remove("hidden");
  els.modal.setAttribute("aria-hidden", "false");
}

function closeModal() {
  els.modal.classList.add("hidden");
  els.modal.setAttribute("aria-hidden", "true");
}

function renderLesson() {
  const lesson = lessons[0];
  const caseItem = dataset.find(item => item.id === lesson.linkedId);

  els.lessonBox.innerHTML = `
    <div class="result-card">
      <div>
        <span class="branch-badge">Учебный кейс</span>
        <h4 class="result-title">${caseItem.article}</h4>
        <p class="muted">Опора на практику: ${caseItem.caseTitle}</p>
      </div>
      <div class="norm-quote"><strong>Вопрос:</strong> ${lesson.question}</div>
      <div class="lesson-options">
        ${lesson.options.map((opt, index) => `<button class="text-link-btn lesson-btn" data-lesson="${lesson.id}" data-option="${index}">${opt.text}</button>`).join("")}
      </div>
      <div id="lessonFeedback" class="lesson-feedback hidden"></div>
    </div>
  `;

  document.querySelectorAll(".lesson-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const selected = lesson.options[Number(btn.dataset.option)];
      const feedback = document.getElementById("lessonFeedback");
      feedback.classList.remove("hidden");
      feedback.innerHTML = `
        <strong>${selected.correct ? "Верно" : "Не совсем"}.</strong><br />
        ${lesson.explanation}
      `;
    });
  });
}

function populateAI() {
  dataset
    .slice()
    .sort((a, b) => a.article.localeCompare(b.article, "ru"))
    .forEach(item => {
      const option = document.createElement("option");
      option.value = String(item.id);
      option.textContent = item.article;
      els.aiNorm.appendChild(option);
    });

  const outcomes = ["Нейтральный ориентир", "Отказ в произвольном расторжении", "Допущение изменения/расторжения", "В пользу слабой стороны", "Подтверждение действительности условия", "Индивидуализация размера", "Уточнение критерия", "Отмена осуждения"];
  const interpretations = [...new Set(dataset.map(item => item.interpretation))];
  fillSelect(els.aiOutcome, outcomes);
  fillSelect(els.aiInterpretation, interpretations);
}

function aiExplain() {
  const itemId = Number(els.aiNorm.value || 0);
  const item = dataset.find(entry => entry.id === itemId);
  const selectedOutcome = els.aiOutcome.value;
  const selectedInterpretation = els.aiInterpretation.value;

  if (!item) {
    els.aiOutput.innerHTML = "Сначала выберите норму.";
    return;
  }

  const explanation = [
    `Анализ по норме <strong>${item.article}</strong>.`,
    `Ключевая каучуковая формула здесь — <strong>«${item.rubberPhrase}»</strong>, поэтому суд не может ограничиться буквальным чтением текста и обычно оценивает контекст спора.`,
    `Если предполагаемый исход — <strong>${selectedOutcome || item.outcomeType}</strong>, то основная логика будет строиться вокруг того, достаточно ли доказаны факты для наполнения оценочной категории конкретным содержанием.`,
    `При типе толкования <strong>${selectedInterpretation || item.interpretation}</strong> суд, как правило, либо усиливает защитную функцию нормы, либо, наоборот, сдерживает чрезмерно широкое применение каучуковой формулы.`,
    `Наиболее вероятные аргументы: ${item.keywords.join(", ")}.`,
    `Опорная практика в демо-каталоге показывает такой вектор: ${item.motivation}`
  ].join("<br /><br />");

  els.aiOutput.innerHTML = explanation;
}

function bindFilters() {
  els.searchInput.addEventListener("input", e => {
    state.q = e.target.value;
    renderResults();
  });

  els.branchFilter.addEventListener("change", e => {
    state.branch = e.target.value;
    renderResults();
  });

  els.jurisdictionFilter.addEventListener("change", e => {
    state.jurisdiction = e.target.value;
    renderResults();
  });

  els.outcomeFilter.addEventListener("change", e => {
    state.outcome = e.target.value;
    renderResults();
  });

  els.interpretationFilter.addEventListener("change", e => {
    state.interpretation = e.target.value;
    renderResults();
  });

  els.yearFilter.addEventListener("change", e => {
    state.year = e.target.value;
    renderResults();
  });

  els.resetBtn.addEventListener("click", () => {
    state.q = "";
    state.branch = "";
    state.jurisdiction = "";
    state.outcome = "";
    state.interpretation = "";
    state.year = "";

    els.searchInput.value = "";
    els.branchFilter.value = "";
    els.jurisdictionFilter.value = "";
    els.outcomeFilter.value = "";
    els.interpretationFilter.value = "";
    els.yearFilter.value = "";
    renderResults();
  });
}

function bindTabs() {
  document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".tab-panel").forEach(panel => panel.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(btn.dataset.tab).classList.add("active");
    });
  });
}

function bindModal() {
  els.modalClose.addEventListener("click", closeModal);
  els.modal.addEventListener("click", e => {
    if (e.target.dataset.close === "true") closeModal();
  });
}

function bindTheme() {
  const saved = localStorage.getItem("kautchuk-theme");
  if (saved === "dark") document.body.classList.add("dark");
  els.themeToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark");
    localStorage.setItem("kautchuk-theme", document.body.classList.contains("dark") ? "dark" : "light");
  });
}

function init() {
  fillSelect(els.branchFilter, uniqueValues("branch"));
  fillSelect(els.jurisdictionFilter, uniqueValues("jurisdiction"));
  fillSelect(els.outcomeFilter, uniqueValues("outcomeType"));
  fillSelect(els.interpretationFilter, uniqueValues("interpretation"));
  fillSelect(els.yearFilter, uniqueValues("year"));

  const placeholderOpt1 = document.createElement("option");
  placeholderOpt1.value = "";
  placeholderOpt1.textContent = "Выберите норму";
  els.aiNorm.appendChild(placeholderOpt1);
  const placeholderOpt2 = document.createElement("option");
  placeholderOpt2.value = "";
  placeholderOpt2.textContent = "Выберите предполагаемый исход";
  els.aiOutcome.appendChild(placeholderOpt2);
  const placeholderOpt3 = document.createElement("option");
  placeholderOpt3.value = "";
  placeholderOpt3.textContent = "Выберите тип толкования";
  els.aiInterpretation.appendChild(placeholderOpt3);

  populateAI();
  renderStats();
  renderResults();
  renderLesson();
  bindFilters();
  bindTabs();
  bindModal();
  bindTheme();

  els.aiExplainBtn.addEventListener("click", aiExplain);
}

init();
